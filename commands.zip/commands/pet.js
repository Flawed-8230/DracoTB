module.exports = {
    name: 'pet',
    description: `Pet draco bot`,
    usage: 'pet',
    aliases: ['interact'],
    run(socket, data, message, args, utils) {
        console.log("this runs btw")
        socket.emit(utils.petresponses[utils.random(0, utils.petresponses.length - 1)]);
    }
  };